import setStorage from "./setStorage.js";
export default function setSortState(order){
    setStorage({order: order})
}
export default function closeUi(){
    setTimeout(()=>{
        window.close()
    }, 100)
}
import test from "./test.js"

test("This is a test")


// console.log("backgroundNew ran HERE")

// function onCreated() {
//     if (browser.runtime.lastError) {
//         console.log(`Error: ${browser.runtime.lastError}`);
//     } else {
//         console.log("Context menu item created successfully");
//     }
// }

// browser.contextMenus.create({
//     id: "add",
//     title: "Add To Playlist",
//     contexts: ["all"],
//     documentUrlPatterns: ["*://www.youtube.com/*"]
// }, onCreated);

export default function test(string){
    console.log(string)
}